import UIKit

//ENCAPSULATION

//baseClass
class Song {
    //fileprivate hanya dapat diakses di file ini
    //internal hanya bisa diakses oleh modul itu saja
    private var songId: String
    public var title: String
    var artist: String
    var lyric: String
    
    init(id: String, title: String,artist: String,lyric: String) {
        self.songId = id
        self.title = title
        self.artist = artist
        self.lyric = lyric
    }
    
    func playSong(title:String) {
        print("Now playing \(title)")
    }
    
    func showLyric() {
        print("Lyric of \(title)")
        print("\(lyric)")
    }
    
    private func stopSong(){
        print("thanks")
    }
}

//create object
let song = Song(id: "1",
        title: "Darari",
        artist: "Treasure",
        lyric: "Lorem ipsum sit dolor amet asi redu..")
//song.stopSong() tidak bisa diakses
//print(song.songId) tidak bisa diakses
print(song.title)

print("\n")
//INHERITANCE

//SubClass
class KoploRemix: Song{
    func playGendang(){
        print("Tak Dung")
    }
    override func showLyric(){
        print("Ayo semua bergoyang")
        super.showLyric()
    }
}

song.playSong(title: "dududu")
let dangdutSong = KoploRemix(id: "1",
        title: "Fancy",
        artist: "Twice",
        lyric: "Lorem ipsum sit dolor amet asi redu..")

dangdutSong.showLyric()
dangdutSong.playGendang()

//NOTE
//struct tidak bisa diinheritance
